def multiple(a, b):
    """
    Returns the product of two numbers.
    """
    return a * b

def multiple(a, b):
    """
    Returns the product of two numbers.
    """
    return int(a) * int(b)
